

<!-- saved from url=(0038)https://chkfull24hr.000webhostapp.com/ -->
<html>
<!-- Mirrored from editfly-chk.xyz/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Oct 2018 02:18:04 GMT -->
<!-- Added by HTTrack -->

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <!-- /Added by HTTrack -->
  <link rel="icon" type="image/png" href="./logo.png">
  <title id="title">𝗡𝗜𝗡𝗝𝗔 𝗖𝗖 𝗖𝗛𝗘𝗖𝗞𝗘𝗥</title>
  <meta name="description" content="">
  <meta name="robots" content="all,follow">
  <link href="https://fonts.googleapis.com/css?family=Tomorrow&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="arquivos/bootstrap.min.css">
  <script src="arquivos/jquery.min.js"></script>
  <link rel="stylesheet" href="arquivos/font-awesome.min.css">
  <link rel="stylesheet" href="arquivos/fontastic.css">
  <link rel="stylesheet" href="arquivos/css">
  <link rel="stylesheet" href="arquivos/style.default.premium.css" id="theme-stylesheet">
  <link id="new-stylesheet" rel="stylesheet">
  <link rel="stylesheet" href="arquivos/custom.css">


  
  <style type="text/css">
    /* Chart.js */
    @-webkit-keyframes chartjs-render-animation {
      from {
        opacity: 0.99
      }

      to {
        opacity: 1
      }
    }

    @keyframes chartjs-render-animation {
      from {
        opacity: 0.99
      }

      to {
        opacity: 1
      }
    }

    .chartjs-render-monitor {
      -webkit-animation: chartjs-render-animation 0.001s;
      animation: chartjs-render-animation 0.001s;
    }
  </style>
  <style type="text/css">
    /* Chart.js */
    @-webkit-keyframes chartjs-render-animation {
      from {
        opacity: 0.99
      }

      to {
        opacity: 1
      }
    }

    @keyframes chartjs-render-animation {
      from {
        opacity: 0.99
      }

      to {
        opacity: 1
      }
    }

    .chartjs-render-monitor {
      -webkit-animation: chartjs-render-animation 0.001s;
      animation: chartjs-render-animation 0.001s;
    }
  </style>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #FFF;
  color:#333;
}

.topnav a {
  float: right;
  display: block;
  color: #333;
  text-align: center;
  padding: 29px 23px;
  text-decoration: none;
  font-size: 18px;
}

.topnavhead {
  float: left;
  display: block;
  color: #333;
  text-align: center;
  padding: 21px 21px;
  text-decoration: none;
  font-size: 25px;
}

.topnav a:hover {
  background-color: #54E69D;
  color: black;
}

.topnavac {
  background-color: #796AEE;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>



<style type="text/css">
  body {

    background: url('image/17580.jpg') no-repeat center center fixed;
    background-size: cover;

    background-size: 100% 100%;
    background-repeat: repeat;
    background-color: #101110;
  }
</style>

<body>
<div class="topnav" id="myTopnav">
    <span class="topnavhead" id="demo"><b><img alt="Image placeholder" style="
    display: inline-block;margin-right: 5px; margin-left: 1px;padding-top: 0px;padding-bottom: 0px; height: 40px; width: 43px;" src="./logo.png"> Ninja Checker</b></span>
      <a href="./about.php" class="topnavac" style="color: white" >About</a>
      <a href="./skcheck.php" >SK Checker</a>
        <a href="./skgen.php">SK Generator</a>
        <a href="./CCGen.php">CC Generator</a>
  <a href="./checker.php">CC Checker</a>



  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
<section class="dashboard-header">

             
        </div>
<center><h1 class="h1" style="font-size: 40px;">About</h1></center>
       <center> <div class="statistics col-lg-9 col-12" style="padding-top: 40px;">
          <div class="statistic bg-white has-shadow">
            <blockquote class="blockquote mb-0 card-body">
           
                 <h3 class="h4"><i class="fa fa-credit-card"></i>    Checker Made By <a href="http://t.me/ninjanaveen" target="_blank">@NinjaNaveen</a> </h3>
                 <h3 class="h4" style="padding-top: 10px;"><i class="fa fa-telegram"></i>    Join Telegram Channel <a href="https://t.me/joinchat/AAAAAEz2wFGuTfGQB1wc2g" target="_blank">Royal Giveaways</a> </h3>
                 <h3 class="h4" style="padding-top: 10px;"><i class="fa fa-telegram"></i>    Join Telegram Group <a href="https://t.me/joinchat/Pphtz0Y_KxMJZaxrxbi12g" target="_blank">Royal Giveaways Chat</a> </h3>
                 <h3 class="h4" style="padding-top: 10px;"><i class="fa fa-telegram"></i>    Official Support Group <a href="https://t.me/NinjaChecker" target="_blank">Ninja Checker Support</a> </h3>
                 <h1 class="h1" style="font-size: 40px;"> </h1>

                 <h1 class="h1" style="font-size: 40px;"> </h1>
                </div><br></center>




                
          </div>
        </div>

       </section>







  <script src="arquivos/jquery.min.js(1)"></script>
  <script src="arquivos/popper.min.js"> </script>
  <script src="arquivos/bootstrap.min.js"></script>
  <script src="arquivos/jquery.cookie.js"> </script>
  <script src="arquivos/Chart.min.js"></script>
  <script src="arquivos/jquery.validate.min.js"></script>
  <script src="arquivos/charts-home.js"></script>


  <script src="arquivos/messenger-theme-flat.js"> </script>
  <script src="arquivos/home-premium.js"> </script>

  <script src="arquivos/front.js"></script>
</body>
</html>
